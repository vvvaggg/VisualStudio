﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BMI.VAG
{
    public partial class BMI : Form
    {
        public BMI()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToDouble(textBox1.Text) / 100;
            double ves = Convert.ToDouble(textBox2.Text);
            int BMI = Convert.ToInt32(ves / (rost * rost));
            label19.Text = BMI.ToString();
            //trackBar1.Value = Convert.ToInt32(BMI) ;
            if (BMI < 10)
            { trackBar1.Value = 10; label19.Text = "недостаточный"; }
            if (BMI < 18.5 && BMI >= 10)
            { trackBar1.Value = Convert.ToInt32(BMI); label20.Text = "недостаточный"; }
            if (BMI >= 18.5 && BMI <= 24.9)
            { trackBar1.Value = Convert.ToInt32(BMI); label20.Text = "здоровый"; }
            if (BMI <= 30 && BMI > 24.9)
            { trackBar1.Value = Convert.ToInt32(BMI); label20.Text = "избыточный"; }
            if (BMI > 30)
            { trackBar1.Value = Convert.ToInt32(BMI); label20.Text = "ожирение"; }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.male_icon;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = Properties.Resources.female_icon;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
        }
    }
}