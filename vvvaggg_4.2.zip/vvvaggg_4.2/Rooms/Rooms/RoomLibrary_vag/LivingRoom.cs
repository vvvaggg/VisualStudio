﻿namespace RoomLibrary_vag
{
    internal class LivingRoom
    {
    }
}